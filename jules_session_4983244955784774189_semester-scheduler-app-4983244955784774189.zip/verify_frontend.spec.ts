import { test, expect } from '@playwright/test';

test('verify scheduler web app functionality', async ({ page }) => {
  await page.setViewportSize({ width: 1280, height: 900 });
  await page.goto('http://localhost:3000');

  // Verify header and title
  await expect(page.locator('h1')).toContainText('Semester Schedule Planner');

  // Take screenshot of main schedule dashboard
  await page.screenshot({ path: 'schedule_dashboard.png', fullPage: true });

  // Click on Teachers tab
  await page.click('#tab-teachers');
  await page.waitForTimeout(300);
  await expect(page.locator('text=Teacher Management')).toBeVisible();

  // Click on Subjects tab
  await page.click('#tab-subjects');
  await page.waitForTimeout(300);
  await expect(page.locator('text=Subject & Course Management')).toBeVisible();

  // Click on Rooms tab
  await page.click('#tab-rooms');
  await page.waitForTimeout(300);
  await expect(page.locator('text=Classroom & Lab Management')).toBeVisible();

  // Click on Settings tab
  await page.click('#tab-settings');
  await page.waitForTimeout(300);
  await expect(page.locator('text=School Operating Hours')).toBeVisible();

  // Go back to Schedule and click Auto-Generate
  await page.click('#tab-schedule');
  await page.click('#auto-generate-btn');
  await page.waitForTimeout(500);

  await page.screenshot({ path: 'auto_generated_schedule.png', fullPage: true });
});
