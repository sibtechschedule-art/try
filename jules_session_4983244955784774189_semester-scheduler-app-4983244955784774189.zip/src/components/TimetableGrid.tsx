import React, { useState } from 'react';
import type { Teacher, Subject, Room, ScheduledSession, ScheduleConflict, DayOfWeek } from '../types/scheduler';
import { AlertTriangle, Repeat, Trash2, User, Home, Clock } from 'lucide-react';

interface TimetableGridProps {
  sessions: ScheduledSession[];
  teachers: Teacher[];
  subjects: Subject[];
  rooms: Room[];
  conflicts: ScheduleConflict[];
  operatingDays: DayOfWeek[];
  operatingStart: string;
  operatingEnd: string;
  onUpdateSession: (updatedSession: ScheduledSession) => void;
  onDeleteSession: (sessionId: string) => void;
  onSwapTeachers: (sessionId1: string, sessionId2: string) => void;
  onAssignTeacherToSession: (sessionId: string, newTeacherId: string) => void;
}

type FilterViewMode = 'all' | 'teacher' | 'room' | 'subject';

export const TimetableGrid: React.FC<TimetableGridProps> = ({
  sessions,
  teachers,
  subjects,
  rooms,
  conflicts,
  operatingDays,
  operatingStart,
  operatingEnd,
  onUpdateSession,
  onDeleteSession,
  onSwapTeachers,
  onAssignTeacherToSession
}) => {
  const [filterMode, setFilterMode] = useState<FilterViewMode>('all');
  const [selectedEntityId, setSelectedEntityId] = useState<string>('');
  
  // Swap modal state
  const [swapTargetModalSession, setSwapTargetModalSession] = useState<ScheduledSession | null>(null);

  // Generate hourly time slots from operatingStart to operatingEnd
  const generateTimeRows = () => {
    const startHour = parseInt(operatingStart.split(':')[0], 10);
    const endHour = parseInt(operatingEnd.split(':')[0], 10);
    const rows: string[] = [];
    for (let h = startHour; h < endHour; h++) {
      const formatted = `${h.toString().padStart(2, '0')}:00`;
      rows.push(formatted);
    }
    return rows;
  };

  const timeRows = generateTimeRows();

  // Filter sessions according to selected view
  const filteredSessions = sessions.filter(s => {
    if (filterMode === 'teacher' && selectedEntityId) return s.teacherId === selectedEntityId;
    if (filterMode === 'room' && selectedEntityId) return s.roomId === selectedEntityId;
    if (filterMode === 'subject' && selectedEntityId) return s.subjectId === selectedEntityId;
    return true;
  });

  // Handle Drag & Drop of Sessions to new Time/Day slots
  const handleDragStartSession = (e: React.DragEvent, sessionId: string) => {
    e.dataTransfer.setData('text/plain', JSON.stringify({ type: 'SESSION', id: sessionId }));
  };

  const handleDragStartTeacher = (e: React.DragEvent, teacherId: string) => {
    e.dataTransfer.setData('text/plain', JSON.stringify({ type: 'TEACHER', id: teacherId }));
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
  };

  const handleDropOnSlot = (e: React.DragEvent, day: DayOfWeek, timeRowStr: string) => {
    e.preventDefault();
    const rawData = e.dataTransfer.getData('text/plain');
    if (!rawData) return;

    try {
      const data = JSON.parse(rawData);
      if (data.type === 'SESSION') {
        const session = sessions.find(s => s.id === data.id);
        if (!session) return;

        // Calculate new end time maintaining duration
        const [oldStartH, oldStartM] = session.startTime.split(':').map(Number);
        const [oldEndH, oldEndM] = session.endTime.split(':').map(Number);
        const durationMins = (oldEndH * 60 + oldEndM) - (oldStartH * 60 + oldStartM);

        const [newStartH, newStartM] = timeRowStr.split(':').map(Number);
        const newEndMins = newStartH * 60 + newStartM + durationMins;
        const newEndH = Math.floor(newEndMins / 60);
        const newEndM = newEndMins % 60;
        const newEndStr = `${newEndH.toString().padStart(2, '0')}:${newEndM.toString().padStart(2, '0')}`;

        onUpdateSession({
          ...session,
          day,
          startTime: timeRowStr,
          endTime: newEndStr
        });
      }
    } catch {
      // Ignore invalid drag data
    }
  };

  const handleDropOnSession = (e: React.DragEvent, targetSession: ScheduledSession) => {
    e.stopPropagation();
    e.preventDefault();
    const rawData = e.dataTransfer.getData('text/plain');
    if (!rawData) return;

    try {
      const data = JSON.parse(rawData);
      if (data.type === 'SESSION' && data.id !== targetSession.id) {
        // Swap teachers or full slots between two sessions
        onSwapTeachers(data.id, targetSession.id);
      } else if (data.type === 'TEACHER') {
        onAssignTeacherToSession(targetSession.id, data.id);
      }
    } catch {
      // Ignore
    }
  };

  return (
    <div className="space-y-6">
      {/* View Filters & Controls */}
      <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-4 flex flex-wrap items-center justify-between gap-4">
        <div className="flex flex-wrap items-center gap-3">
          <span className="text-sm font-semibold text-slate-700">Filter Schedule By:</span>
          <div className="flex rounded-lg border border-slate-200 bg-slate-100 p-0.5 text-xs font-medium">
            <button
              onClick={() => { setFilterMode('all'); setSelectedEntityId(''); }}
              className={`px-3 py-1.5 rounded-md transition cursor-pointer ${
                filterMode === 'all' ? 'bg-white text-indigo-600 shadow-xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Master Schedule
            </button>
            <button
              onClick={() => { setFilterMode('teacher'); setSelectedEntityId(teachers[0]?.id || ''); }}
              className={`px-3 py-1.5 rounded-md transition cursor-pointer ${
                filterMode === 'teacher' ? 'bg-white text-indigo-600 shadow-xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              By Teacher
            </button>
            <button
              onClick={() => { setFilterMode('room'); setSelectedEntityId(rooms[0]?.id || ''); }}
              className={`px-3 py-1.5 rounded-md transition cursor-pointer ${
                filterMode === 'room' ? 'bg-white text-indigo-600 shadow-xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              By Room
            </button>
            <button
              onClick={() => { setFilterMode('subject'); setSelectedEntityId(subjects[0]?.id || ''); }}
              className={`px-3 py-1.5 rounded-md transition cursor-pointer ${
                filterMode === 'subject' ? 'bg-white text-indigo-600 shadow-xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              By Subject
            </button>
          </div>

          {filterMode === 'teacher' && (
            <select
              value={selectedEntityId}
              onChange={e => setSelectedEntityId(e.target.value)}
              className="px-3 py-1.5 border border-slate-300 rounded-lg text-xs bg-white text-slate-800 font-medium"
            >
              {teachers.map(t => (
                <option key={t.id} value={t.id}>{t.name}</option>
              ))}
            </select>
          )}

          {filterMode === 'room' && (
            <select
              value={selectedEntityId}
              onChange={e => setSelectedEntityId(e.target.value)}
              className="px-3 py-1.5 border border-slate-300 rounded-lg text-xs bg-white text-slate-800 font-medium"
            >
              {rooms.map(r => (
                <option key={r.id} value={r.id}>{r.name}</option>
              ))}
            </select>
          )}

          {filterMode === 'subject' && (
            <select
              value={selectedEntityId}
              onChange={e => setSelectedEntityId(e.target.value)}
              className="px-3 py-1.5 border border-slate-300 rounded-lg text-xs bg-white text-slate-800 font-medium"
            >
              {subjects.map(s => (
                <option key={s.id} value={s.id}>{s.code} - {s.name}</option>
              ))}
            </select>
          )}
        </div>

        {/* Quick Teacher Palette for dragging teacher onto schedule */}
        <div className="flex items-center gap-2 overflow-x-auto py-1">
          <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider flex items-center gap-1">
            <User className="w-3.5 h-3.5 text-indigo-600" /> Drag Teacher to Assign:
          </span>
          <div className="flex items-center gap-1.5">
            {teachers.map(t => (
              <div
                key={t.id}
                draggable
                onDragStart={e => handleDragStartTeacher(e, t.id)}
                className="px-2.5 py-1 rounded-full bg-slate-100 hover:bg-indigo-50 hover:border-indigo-300 text-slate-700 text-xs font-medium border border-slate-200 cursor-grab active:cursor-grabbing transition shadow-2xs"
                title="Drag teacher onto a session to swap/reassign teacher"
              >
                {t.name.split(' ')[1] || t.name}
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Main Timetable Grid */}
      <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-x-auto">
        <table className="w-full border-collapse min-w-[800px]">
          <thead>
            <tr className="bg-slate-50 border-b border-slate-200 text-xs font-semibold text-slate-600 uppercase tracking-wider">
              <th className="py-3 px-4 text-left w-24 border-r border-slate-200">
                <Clock className="w-4 h-4 text-slate-400 inline mr-1" /> Time
              </th>
              {operatingDays.map(day => (
                <th key={day} className="py-3 px-4 text-center border-r border-slate-200 last:border-r-0">
                  {day}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {timeRows.map(timeStr => (
              <tr key={timeStr} className="border-b border-slate-100 min-h-[90px]">
                <td className="py-3 px-3 text-xs font-mono font-medium text-slate-500 bg-slate-50/50 border-r border-slate-200 align-top">
                  {timeStr}
                </td>
                {operatingDays.map(day => {
                  // Find sessions that start in this hour cell on this day
                  const cellSessions = filteredSessions.filter(s => {
                    const startH = s.startTime.split(':')[0];
                    return s.day === day && startH === timeStr.split(':')[0];
                  });

                  return (
                    <td
                      key={`${day}-${timeStr}`}
                      onDragOver={handleDragOver}
                      onDrop={e => handleDropOnSlot(e, day, timeStr)}
                      className="p-1.5 border-r border-slate-200 last:border-r-0 align-top bg-white hover:bg-slate-50/50 transition relative min-h-[80px]"
                    >
                      <div className="space-y-1.5">
                        {cellSessions.map(session => {
                          const teacher = teachers.find(t => t.id === session.teacherId);
                          const subject = subjects.find(s => s.id === session.subjectId);
                          const room = rooms.find(r => r.id === session.roomId);

                          // Find conflicts for this session
                          const sessionConflicts = conflicts.filter(c => c.sessionId === session.id);
                          const hasError = sessionConflicts.some(c => c.severity === 'error');
                          const hasWarning = sessionConflicts.some(c => c.severity === 'warning');

                          return (
                            <div
                              key={session.id}
                              draggable
                              onDragStart={e => handleDragStartSession(e, session.id)}
                              onDragOver={handleDragOver}
                              onDrop={e => handleDropOnSession(e, session)}
                              className={`p-2.5 rounded-lg border text-xs shadow-xs transition cursor-grab active:cursor-grabbing relative group ${
                                hasError
                                  ? 'bg-rose-50 border-rose-400 text-rose-900 ring-2 ring-rose-400'
                                  : hasWarning
                                  ? 'bg-amber-50 border-amber-400 text-amber-900'
                                  : 'bg-indigo-50/70 border-indigo-200 text-indigo-950 hover:border-indigo-400'
                              }`}
                              style={{
                                borderLeftWidth: '4px',
                                borderLeftColor: subject?.color || (hasError ? '#f43f5e' : '#6366f1')
                              }}
                            >
                              {/* Conflict Alert Ping Badge */}
                              {(hasError || hasWarning) && (
                                <div className="absolute -top-2 -right-2 z-10 animate-bounce">
                                  <span className={`flex h-5 w-5 items-center justify-center rounded-full text-[10px] font-bold text-white shadow-md ${
                                    hasError ? 'bg-rose-600' : 'bg-amber-500'
                                  }`}>
                                    !
                                  </span>
                                </div>
                              )}

                              {/* Session Code & Name */}
                              <div className="flex justify-between items-start gap-1">
                                <span className="font-bold text-slate-900 uppercase tracking-tight">
                                  {subject?.code || 'CS101'}
                                </span>
                                <div className="flex items-center gap-1 opacity-80 group-hover:opacity-100">
                                  <button
                                    onClick={() => setSwapTargetModalSession(session)}
                                    className="p-0.5 text-slate-400 hover:text-indigo-600 rounded cursor-pointer"
                                    title="Quick Swap Teacher"
                                  >
                                    <Repeat className="w-3 h-3" />
                                  </button>
                                  <button
                                    onClick={() => onDeleteSession(session.id)}
                                    className="p-0.5 text-slate-400 hover:text-rose-600 rounded cursor-pointer"
                                    title="Delete Session"
                                  >
                                    <Trash2 className="w-3 h-3" />
                                  </button>
                                </div>
                              </div>

                              <div className="font-medium truncate text-[11px] text-slate-700 mt-0.5">
                                {subject?.name || 'Subject'}
                              </div>

                              {/* Time Details */}
                              <div className="text-[10px] font-mono text-slate-500 mt-1 flex items-center gap-1">
                                <Clock className="w-3 h-3 text-slate-400" />
                                {session.startTime} - {session.endTime}
                              </div>

                              {/* Teacher & Room */}
                              <div className="mt-1.5 pt-1.5 border-t border-slate-200/60 flex flex-wrap items-center justify-between gap-1 text-[10px]">
                                <span className="font-semibold text-slate-800 flex items-center gap-1">
                                  <User className="w-3 h-3 text-indigo-600" />
                                  {teacher ? teacher.name : 'No Teacher'}
                                </span>
                                <span className="text-slate-600 flex items-center gap-1 bg-white px-1.5 py-0.5 rounded border border-slate-200">
                                  <Home className="w-3 h-3 text-slate-400" />
                                  {room ? room.name : 'No Room'}
                                </span>
                              </div>

                              {/* Hover Conflict Tooltip / Warning Message */}
                              {sessionConflicts.length > 0 && (
                                <div className="mt-2 text-[10px] bg-white p-1.5 rounded border border-rose-200 text-rose-700 font-sans space-y-0.5 shadow-xs">
                                  {sessionConflicts.map(c => (
                                    <div key={c.id} className="flex items-start gap-1">
                                      <AlertTriangle className="w-3 h-3 shrink-0 text-rose-500 mt-0.5" />
                                      <span>{c.message}</span>
                                    </div>
                                  ))}
                                </div>
                              )}
                            </div>
                          );
                        })}
                      </div>
                    </td>
                  );
                })}
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Teacher Swap Modal */}
      {swapTargetModalSession && (
        <div className="fixed inset-0 bg-slate-900/50 flex items-center justify-center p-4 z-50 backdrop-blur-xs">
          <div className="bg-white rounded-xl shadow-xl max-w-md w-full p-6">
            <h3 className="text-lg font-bold text-slate-800 mb-2 flex items-center gap-2">
              <Repeat className="w-5 h-5 text-indigo-600" /> Quick Swap Teacher
            </h3>
            <p className="text-xs text-slate-500 mb-4">
              Select an available qualified teacher to swap or re-assign for this session.
            </p>

            <div className="space-y-2 mb-6">
              {teachers.map(t => {
                const isCurrent = t.id === swapTargetModalSession.teacherId;
                const subject = subjects.find(s => s.id === swapTargetModalSession.subjectId);
                const isQualified = subject && t.qualifiedSubjectIds.includes(subject.id);

                return (
                  <button
                    key={t.id}
                    onClick={() => {
                      onAssignTeacherToSession(swapTargetModalSession.id, t.id);
                      setSwapTargetModalSession(null);
                    }}
                    className={`w-full text-left p-3 rounded-lg border text-xs flex justify-between items-center transition cursor-pointer ${
                      isCurrent
                        ? 'bg-indigo-50 border-indigo-300 font-bold text-indigo-900'
                        : 'bg-white border-slate-200 hover:bg-slate-50 text-slate-800'
                    }`}
                  >
                    <div>
                      <span className="font-semibold block text-slate-900">{t.name}</span>
                      <span className="text-[10px] text-slate-500">
                        {isQualified ? 'Qualified for this subject' : 'Not marked qualified'}
                      </span>
                    </div>
                    {isCurrent && (
                      <span className="text-[10px] bg-indigo-200 text-indigo-800 px-2 py-0.5 rounded font-medium">
                        Assigned
                      </span>
                    )}
                  </button>
                );
              })}
            </div>

            <div className="flex justify-end">
              <button
                onClick={() => setSwapTargetModalSession(null)}
                className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-xs font-semibold cursor-pointer"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
