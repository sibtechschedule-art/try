import React, { useState } from 'react';
import type { Teacher, Subject } from '../types/scheduler';
import { DAYS_OF_WEEK } from '../types/scheduler';
import { UserCheck, Plus, Trash2, Edit2, Clock, Check, X, BookOpen } from 'lucide-react';

interface TeacherManagerProps {
  teachers: Teacher[];
  subjects: Subject[];
  onAddTeacher: (teacher: Teacher) => void;
  onUpdateTeacher: (teacher: Teacher) => void;
  onDeleteTeacher: (id: string) => void;
}

export const TeacherManager: React.FC<TeacherManagerProps> = ({
  teachers,
  subjects,
  onAddTeacher,
  onUpdateTeacher,
  onDeleteTeacher,
}) => {
  const [editingTeacher, setEditingTeacher] = useState<Partial<Teacher> | null>(null);
  const [isCreating, setIsCreating] = useState(false);

  const startNewTeacher = () => {
    setEditingTeacher({
      id: 't-' + Date.now(),
      name: '',
      email: '',
      qualifiedSubjectIds: [],
      availability: DAYS_OF_WEEK.map(day => ({
        day,
        slots: [{ start: '08:00', end: '17:00' }]
      }))
    });
    setIsCreating(true);
  };

  const handleSave = () => {
    if (!editingTeacher?.name) return;
    const fullTeacher: Teacher = {
      id: editingTeacher.id || 't-' + Date.now(),
      name: editingTeacher.name || 'Unnamed Teacher',
      email: editingTeacher.email || '',
      qualifiedSubjectIds: editingTeacher.qualifiedSubjectIds || [],
      availability: editingTeacher.availability || []
    };

    if (isCreating) {
      onAddTeacher(fullTeacher);
    } else {
      onUpdateTeacher(fullTeacher);
    }
    setEditingTeacher(null);
    setIsCreating(false);
  };

  const toggleSubjectQualification = (subjectId: string) => {
    if (!editingTeacher) return;
    const current = editingTeacher.qualifiedSubjectIds || [];
    const updated = current.includes(subjectId)
      ? current.filter(id => id !== subjectId)
      : [...current, subjectId];
    setEditingTeacher({ ...editingTeacher, qualifiedSubjectIds: updated });
  };

  const handleTimeSlotChange = (dayIndex: number, slotIndex: number, field: 'start' | 'end', value: string) => {
    if (!editingTeacher || !editingTeacher.availability) return;
    const newAvail = [...editingTeacher.availability];
    newAvail[dayIndex].slots[slotIndex][field] = value;
    setEditingTeacher({ ...editingTeacher, availability: newAvail });
  };

  const toggleDayAvailable = (dayIndex: number) => {
    if (!editingTeacher || !editingTeacher.availability) return;
    const newAvail = [...editingTeacher.availability];
    if (newAvail[dayIndex].slots.length > 0) {
      newAvail[dayIndex].slots = [];
    } else {
      newAvail[dayIndex].slots = [{ start: '08:00', end: '17:00' }];
    }
    setEditingTeacher({ ...editingTeacher, availability: newAvail });
  };

  return (
    <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h2 className="text-xl font-bold text-slate-800 flex items-center gap-2">
            <UserCheck className="w-6 h-6 text-indigo-600" />
            Teacher Management
          </h2>
          <p className="text-sm text-slate-500">
            Define instructors, their qualified subjects, and weekly time availability.
          </p>
        </div>
        <button
          onClick={startNewTeacher}
          className="flex items-center gap-2 bg-indigo-600 text-white px-4 py-2 rounded-lg hover:bg-indigo-700 font-medium text-sm transition cursor-pointer"
        >
          <Plus className="w-4 h-4" /> Add Teacher
        </button>
      </div>

      {/* Grid of Teachers */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {teachers.map(teacher => {
          const teacherSubjects = subjects.filter(s => teacher.qualifiedSubjectIds.includes(s.id));
          return (
            <div
              key={teacher.id}
              className="border border-slate-200 rounded-lg p-4 bg-slate-50/50 hover:shadow-md transition flex flex-col justify-between"
            >
              <div>
                <div className="flex justify-between items-start mb-2">
                  <div>
                    <h3 className="font-semibold text-slate-900">{teacher.name}</h3>
                    <p className="text-xs text-slate-500">{teacher.email || 'No email provided'}</p>
                  </div>
                  <div className="flex items-center gap-1">
                    <button
                      onClick={() => {
                        setEditingTeacher(teacher);
                        setIsCreating(false);
                      }}
                      className="p-1 text-slate-400 hover:text-indigo-600 rounded cursor-pointer"
                      title="Edit Teacher"
                    >
                      <Edit2 className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => onDeleteTeacher(teacher.id)}
                      className="p-1 text-slate-400 hover:text-rose-600 rounded cursor-pointer"
                      title="Delete Teacher"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                {/* Qualified Subjects */}
                <div className="mb-3">
                  <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider block mb-1">
                    Qualified Subjects:
                  </span>
                  <div className="flex flex-wrap gap-1">
                    {teacherSubjects.length > 0 ? (
                      teacherSubjects.map(sub => (
                        <span
                          key={sub.id}
                          className="text-xs px-2 py-0.5 rounded-full bg-indigo-50 text-indigo-700 border border-indigo-200 font-medium"
                        >
                          {sub.code} - {sub.name}
                        </span>
                      ))
                    ) : (
                      <span className="text-xs text-slate-400 italic">No qualified subjects assigned</span>
                    )}
                  </div>
                </div>

                {/* Time Availability summary */}
                <div>
                  <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider block mb-1">
                    Availability:
                  </span>
                  <div className="text-xs text-slate-600 space-y-0.5">
                    {teacher.availability?.map(a => (
                      <div key={a.day} className="flex justify-between items-center py-0.5 border-b border-slate-100 last:border-none">
                        <span className="font-medium text-slate-700">{a.day.substring(0, 3)}:</span>
                        <span>
                          {a.slots.length > 0
                            ? a.slots.map(s => `${s.start}-${s.end}`).join(', ')
                            : 'Unavailable'}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Edit/Create Modal */}
      {editingTeacher && (
        <div className="fixed inset-0 bg-slate-900/50 flex items-center justify-center p-4 z-50 backdrop-blur-xs">
          <div className="bg-white rounded-xl shadow-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto p-6">
            <div className="flex justify-between items-center mb-4 border-b pb-3 border-slate-100">
              <h3 className="text-lg font-bold text-slate-800">
                {isCreating ? 'Add New Teacher' : 'Edit Teacher Profile'}
              </h3>
              <button
                onClick={() => setEditingTeacher(null)}
                className="text-slate-400 hover:text-slate-600 p-1 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Teacher Full Name</label>
                <input
                  type="text"
                  value={editingTeacher.name || ''}
                  onChange={e => setEditingTeacher({ ...editingTeacher, name: e.target.value })}
                  placeholder="e.g. Dr. Alan Turing"
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:outline-none text-sm text-slate-800 bg-white"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Email Address</label>
                <input
                  type="email"
                  value={editingTeacher.email || ''}
                  onChange={e => setEditingTeacher({ ...editingTeacher, email: e.target.value })}
                  placeholder="e.g. alan.turing@school.edu"
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:outline-none text-sm text-slate-800 bg-white"
                />
              </div>

              {/* Subjects Checklist */}
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2 flex items-center gap-1.5">
                  <BookOpen className="w-4 h-4 text-indigo-600" /> Subjects Qualified to Teach
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 max-h-40 overflow-y-auto p-2 border border-slate-200 rounded-lg bg-slate-50">
                  {subjects.map(sub => {
                    const isChecked = editingTeacher.qualifiedSubjectIds?.includes(sub.id);
                    return (
                      <label
                        key={sub.id}
                        className={`flex items-center gap-2 p-2 rounded border cursor-pointer transition ${
                          isChecked ? 'bg-indigo-50 border-indigo-300 text-indigo-900 font-medium' : 'bg-white border-slate-200 text-slate-700'
                        }`}
                      >
                        <input
                          type="checkbox"
                          checked={isChecked}
                          onChange={() => toggleSubjectQualification(sub.id)}
                          className="rounded text-indigo-600 focus:ring-indigo-500"
                        />
                        <span className="text-xs">
                          <strong className="text-slate-900 font-semibold">{sub.code}:</strong> {sub.name}
                        </span>
                      </label>
                    );
                  })}
                </div>
              </div>

              {/* Weekly Time Availability */}
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2 flex items-center gap-1.5">
                  <Clock className="w-4 h-4 text-indigo-600" /> Weekly Time Availability
                </label>
                <div className="space-y-2 border border-slate-200 rounded-lg p-3 bg-slate-50">
                  {editingTeacher.availability?.map((dayAvail, dayIdx) => (
                    <div key={dayAvail.day} className="flex flex-wrap items-center justify-between bg-white p-2 rounded border border-slate-200 text-xs">
                      <div className="flex items-center gap-2 w-32">
                        <input
                          type="checkbox"
                          id={`avail-day-${dayAvail.day}`}
                          checked={dayAvail.slots.length > 0}
                          onChange={() => toggleDayAvailable(dayIdx)}
                          className="rounded text-indigo-600 cursor-pointer"
                        />
                        <label htmlFor={`avail-day-${dayAvail.day}`} className="font-semibold text-slate-800 cursor-pointer">
                          {dayAvail.day}
                        </label>
                      </div>

                      {dayAvail.slots.length > 0 ? (
                        <div className="flex items-center gap-2">
                          <span className="text-slate-500">From</span>
                          <input
                            type="time"
                            value={dayAvail.slots[0]?.start || '08:00'}
                            onChange={e => handleTimeSlotChange(dayIdx, 0, 'start', e.target.value)}
                            className="border border-slate-300 rounded px-1.5 py-1 text-slate-800 bg-white"
                          />
                          <span className="text-slate-500">To</span>
                          <input
                            type="time"
                            value={dayAvail.slots[0]?.end || '17:00'}
                            onChange={e => handleTimeSlotChange(dayIdx, 0, 'end', e.target.value)}
                            className="border border-slate-300 rounded px-1.5 py-1 text-slate-800 bg-white"
                          />
                        </div>
                      ) : (
                        <span className="text-slate-400 italic">Not available on this day</span>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            </div>

            <div className="flex justify-end gap-3 mt-6 border-t pt-4 border-slate-100">
              <button
                onClick={() => setEditingTeacher(null)}
                className="px-4 py-2 border border-slate-300 rounded-lg text-slate-700 hover:bg-slate-50 font-medium text-sm cursor-pointer"
              >
                Cancel
              </button>
              <button
                onClick={handleSave}
                className="flex items-center gap-1.5 bg-indigo-600 text-white px-4 py-2 rounded-lg hover:bg-indigo-700 font-medium text-sm cursor-pointer"
              >
                <Check className="w-4 h-4" /> Save Teacher
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
