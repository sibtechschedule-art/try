import React, { useState } from 'react';
import type { Subject, Teacher, HourCalculationMode } from '../types/scheduler';
import { BookOpen, Plus, Trash2, Edit2, Check, X, Users } from 'lucide-react';

interface SubjectManagerProps {
  subjects: Subject[];
  teachers: Teacher[];
  onAddSubject: (subject: Subject) => void;
  onUpdateSubject: (subject: Subject) => void;
  onDeleteSubject: (id: string) => void;
}

const PRESET_COLORS = [
  '#3b82f6', // blue
  '#10b981', // green
  '#f59e0b', // amber
  '#8b5cf6', // purple
  '#ec4899', // pink
  '#06b6d4', // cyan
  '#f97316', // orange
  '#64748b'  // slate
];

export const SubjectManager: React.FC<SubjectManagerProps> = ({
  subjects,
  teachers,
  onAddSubject,
  onUpdateSubject,
  onDeleteSubject,
}) => {
  const [editingSubject, setEditingSubject] = useState<Partial<Subject> | null>(null);
  const [isCreating, setIsCreating] = useState(false);

  const startNewSubject = () => {
    setEditingSubject({
      id: 'sub-' + Date.now(),
      name: '',
      code: '',
      color: PRESET_COLORS[Math.floor(Math.random() * PRESET_COLORS.length)],
      calculationMode: 'weekly',
      totalSemesterHours: 45,
      weeksInSemester: 15,
      hoursPerWeek: 3,
      sessionsPerWeek: 2,
      sessionDurationHours: 1.5,
      preferredTeacherIds: []
    });
    setIsCreating(true);
  };

  const handleModeChange = (mode: HourCalculationMode) => {
    if (!editingSubject) return;
    const weeks = editingSubject.weeksInSemester || 15;
    let hoursPerWeek = editingSubject.hoursPerWeek || 3;
    let totalSemesterHours = editingSubject.totalSemesterHours || 45;

    if (mode === 'semester') {
      hoursPerWeek = Math.round((totalSemesterHours / weeks) * 10) / 10;
    } else {
      totalSemesterHours = hoursPerWeek * weeks;
    }

    const sessions = editingSubject.sessionsPerWeek || 2;
    const duration = Math.round((hoursPerWeek / sessions) * 10) / 10;

    setEditingSubject({
      ...editingSubject,
      calculationMode: mode,
      hoursPerWeek,
      totalSemesterHours,
      sessionDurationHours: duration
    });
  };

  const handleTotalHoursChange = (val: number) => {
    if (!editingSubject) return;
    const weeks = editingSubject.weeksInSemester || 15;
    const hoursPerWeek = Math.round((val / weeks) * 10) / 10;
    const sessions = editingSubject.sessionsPerWeek || 1;
    const duration = Math.round((hoursPerWeek / sessions) * 10) / 10;

    setEditingSubject({
      ...editingSubject,
      totalSemesterHours: val,
      hoursPerWeek,
      sessionDurationHours: duration
    });
  };

  const handleWeeklyHoursChange = (val: number) => {
    if (!editingSubject) return;
    const weeks = editingSubject.weeksInSemester || 15;
    const totalSemesterHours = val * weeks;
    const sessions = editingSubject.sessionsPerWeek || 1;
    const duration = Math.round((val / sessions) * 10) / 10;

    setEditingSubject({
      ...editingSubject,
      hoursPerWeek: val,
      totalSemesterHours,
      sessionDurationHours: duration
    });
  };

  const handleSessionsChange = (val: number) => {
    if (!editingSubject) return;
    const sessions = Math.max(1, val);
    const hoursPerWeek = editingSubject.hoursPerWeek || 3;
    const duration = Math.round((hoursPerWeek / sessions) * 10) / 10;

    setEditingSubject({
      ...editingSubject,
      sessionsPerWeek: sessions,
      sessionDurationHours: duration
    });
  };

  const handleSave = () => {
    if (!editingSubject?.name || !editingSubject?.code) return;

    const fullSubject: Subject = {
      id: editingSubject.id || 'sub-' + Date.now(),
      name: editingSubject.name || 'Unnamed Subject',
      code: editingSubject.code || 'CODE101',
      color: editingSubject.color || '#3b82f6',
      calculationMode: editingSubject.calculationMode || 'weekly',
      totalSemesterHours: editingSubject.totalSemesterHours || 45,
      weeksInSemester: editingSubject.weeksInSemester || 15,
      hoursPerWeek: editingSubject.hoursPerWeek || 3,
      sessionsPerWeek: editingSubject.sessionsPerWeek || 2,
      sessionDurationHours: editingSubject.sessionDurationHours || 1.5,
      preferredTeacherIds: editingSubject.preferredTeacherIds || []
    };

    if (isCreating) {
      onAddSubject(fullSubject);
    } else {
      onUpdateSubject(fullSubject);
    }
    setEditingSubject(null);
    setIsCreating(false);
  };

  return (
    <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h2 className="text-xl font-bold text-slate-800 flex items-center gap-2">
            <BookOpen className="w-6 h-6 text-indigo-600" />
            Subject & Course Management
          </h2>
          <p className="text-sm text-slate-500">
            Define course codes, required hours per week/semester, required session count, and teacher assignments.
          </p>
        </div>
        <button
          onClick={startNewSubject}
          className="flex items-center gap-2 bg-indigo-600 text-white px-4 py-2 rounded-lg hover:bg-indigo-700 font-medium text-sm transition cursor-pointer"
        >
          <Plus className="w-4 h-4" /> Add Subject
        </button>
      </div>

      {/* Grid of Subjects */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {subjects.map(subject => {
          const qualifiedTeachers = teachers.filter(t => t.qualifiedSubjectIds.includes(subject.id));
          return (
            <div
              key={subject.id}
              className="border border-slate-200 rounded-lg p-4 bg-slate-50/50 hover:shadow-md transition flex flex-col justify-between"
              style={{ borderLeftWidth: '4px', borderLeftColor: subject.color || '#3b82f6' }}
            >
              <div>
                <div className="flex justify-between items-start mb-2">
                  <div>
                    <span className="text-xs font-bold px-2 py-0.5 rounded bg-slate-200 text-slate-800 font-mono">
                      {subject.code}
                    </span>
                    <h3 className="font-semibold text-slate-900 mt-1">{subject.name}</h3>
                  </div>
                  <div className="flex items-center gap-1">
                    <button
                      onClick={() => {
                        setEditingSubject(subject);
                        setIsCreating(false);
                      }}
                      className="p-1 text-slate-400 hover:text-indigo-600 rounded cursor-pointer"
                      title="Edit Subject"
                    >
                      <Edit2 className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => onDeleteSubject(subject.id)}
                      className="p-1 text-slate-400 hover:text-rose-600 rounded cursor-pointer"
                      title="Delete Subject"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                <div className="text-xs text-slate-600 space-y-1 mb-3 bg-white p-2.5 rounded border border-slate-100">
                  <div className="flex justify-between">
                    <span className="text-slate-500">Calc Mode:</span>
                    <span className="font-medium capitalize">{subject.calculationMode}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">Weekly Target:</span>
                    <span className="font-semibold text-indigo-600">{subject.hoursPerWeek} hrs/week</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">Semester Total:</span>
                    <span className="font-medium">{subject.totalSemesterHours} hrs ({subject.weeksInSemester} wks)</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">Required Sessions:</span>
                    <span className="font-medium">{subject.sessionsPerWeek} session(s) × {subject.sessionDurationHours}h</span>
                  </div>
                </div>

                {/* Qualified Teachers list */}
                <div>
                  <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider block mb-1">
                    Qualified Teachers ({qualifiedTeachers.length}):
                  </span>
                  <div className="flex flex-wrap gap-1">
                    {qualifiedTeachers.length > 0 ? (
                      qualifiedTeachers.map(t => (
                        <span
                          key={t.id}
                          className="text-xs px-2 py-0.5 rounded bg-emerald-50 text-emerald-700 border border-emerald-200 font-medium"
                        >
                          {t.name}
                        </span>
                      ))
                    ) : (
                      <span className="text-xs text-amber-600 italic">No qualified teachers assigned!</span>
                    )}
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Edit / Create Subject Modal */}
      {editingSubject && (
        <div className="fixed inset-0 bg-slate-900/50 flex items-center justify-center p-4 z-50 backdrop-blur-xs">
          <div className="bg-white rounded-xl shadow-xl max-w-xl w-full max-h-[90vh] overflow-y-auto p-6">
            <div className="flex justify-between items-center mb-4 border-b pb-3 border-slate-100">
              <h3 className="text-lg font-bold text-slate-800">
                {isCreating ? 'Add New Subject / Course' : 'Edit Subject Details'}
              </h3>
              <button
                onClick={() => setEditingSubject(null)}
                className="text-slate-400 hover:text-slate-600 p-1 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-4">
              <div className="grid grid-cols-3 gap-3">
                <div className="col-span-1">
                  <label className="block text-sm font-medium text-slate-700 mb-1">Course Code</label>
                  <input
                    type="text"
                    value={editingSubject.code || ''}
                    onChange={e => setEditingSubject({ ...editingSubject, code: e.target.value.toUpperCase() })}
                    placeholder="e.g. CS101"
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:outline-none uppercase font-mono text-sm text-slate-800 bg-white"
                  />
                </div>
                <div className="col-span-2">
                  <label className="block text-sm font-medium text-slate-700 mb-1">Subject Name</label>
                  <input
                    type="text"
                    value={editingSubject.name || ''}
                    onChange={e => setEditingSubject({ ...editingSubject, name: e.target.value })}
                    placeholder="e.g. Intro to Computer Science"
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:outline-none text-sm text-slate-800 bg-white"
                  />
                </div>
              </div>

              {/* Color picker */}
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Color Theme</label>
                <div className="flex items-center gap-2">
                  {PRESET_COLORS.map(c => (
                    <button
                      key={c}
                      type="button"
                      onClick={() => setEditingSubject({ ...editingSubject, color: c })}
                      className={`w-7 h-7 rounded-full border-2 transition cursor-pointer ${
                        editingSubject.color === c ? 'border-slate-900 scale-110' : 'border-transparent'
                      }`}
                      style={{ backgroundColor: c }}
                    />
                  ))}
                </div>
              </div>

              {/* Calculation Mode Toggle */}
              <div className="p-3 bg-slate-50 border border-slate-200 rounded-lg space-y-3">
                <label className="block text-xs font-semibold uppercase text-slate-500 tracking-wider">
                  Hour Calculation Mode
                </label>
                <div className="flex gap-4">
                  <label className="flex items-center gap-2 text-sm text-slate-700 cursor-pointer">
                    <input
                      type="radio"
                      name="calcMode"
                      checked={editingSubject.calculationMode === 'weekly'}
                      onChange={() => handleModeChange('weekly')}
                      className="text-indigo-600 focus:ring-indigo-500"
                    />
                    Whole Week Hours
                  </label>
                  <label className="flex items-center gap-2 text-sm text-slate-700 cursor-pointer">
                    <input
                      type="radio"
                      name="calcMode"
                      checked={editingSubject.calculationMode === 'semester'}
                      onChange={() => handleModeChange('semester')}
                      className="text-indigo-600 focus:ring-indigo-500"
                    />
                    Whole Semester Hours
                  </label>
                </div>

                <div className="grid grid-cols-2 gap-3 pt-2">
                  {editingSubject.calculationMode === 'semester' ? (
                    <div>
                      <label className="block text-xs text-slate-600 font-medium mb-1">Semester Total (Hours)</label>
                      <input
                        type="number"
                        min="1"
                        value={editingSubject.totalSemesterHours || 45}
                        onChange={e => handleTotalHoursChange(parseFloat(e.target.value) || 0)}
                        className="w-full px-3 py-1.5 border border-slate-300 rounded-lg text-sm bg-white"
                      />
                    </div>
                  ) : (
                    <div>
                      <label className="block text-xs text-slate-600 font-medium mb-1">Weekly Target (Hours)</label>
                      <input
                        type="number"
                        min="0.5"
                        step="0.5"
                        value={editingSubject.hoursPerWeek || 3}
                        onChange={e => handleWeeklyHoursChange(parseFloat(e.target.value) || 0)}
                        className="w-full px-3 py-1.5 border border-slate-300 rounded-lg text-sm bg-white"
                      />
                    </div>
                  )}

                  <div>
                    <label className="block text-xs text-slate-600 font-medium mb-1">Weeks in Semester</label>
                    <input
                      type="number"
                      min="1"
                      value={editingSubject.weeksInSemester || 15}
                      onChange={e => {
                        const weeks = parseInt(e.target.value) || 15;
                        setEditingSubject({ ...editingSubject, weeksInSemester: weeks });
                      }}
                      className="w-full px-3 py-1.5 border border-slate-300 rounded-lg text-sm bg-white"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3 border-t border-slate-200 pt-2">
                  <div>
                    <label className="block text-xs text-slate-600 font-medium mb-1">Sessions Per Week</label>
                    <input
                      type="number"
                      min="1"
                      max="5"
                      value={editingSubject.sessionsPerWeek || 2}
                      onChange={e => handleSessionsChange(parseInt(e.target.value) || 1)}
                      className="w-full px-3 py-1.5 border border-slate-300 rounded-lg text-sm bg-white"
                    />
                  </div>
                  <div>
                    <label className="block text-xs text-slate-600 font-medium mb-1">Computed Duration per Session</label>
                    <div className="px-3 py-1.5 bg-slate-200 rounded-lg text-sm font-semibold text-slate-800">
                      {editingSubject.sessionDurationHours || 1.5} Hours ({ (editingSubject.sessionDurationHours || 1.5) * 60 } mins)
                    </div>
                  </div>
                </div>
              </div>

              {/* Qualified Teachers List */}
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2 flex items-center gap-1.5">
                  <Users className="w-4 h-4 text-indigo-600" /> Teachers Qualified for this Subject
                </label>
                <div className="space-y-1.5 max-h-40 overflow-y-auto p-2 border border-slate-200 rounded-lg bg-slate-50">
                  {teachers.map(teacher => {
                    const isQualified = teacher.qualifiedSubjectIds.includes(editingSubject.id || '');
                    return (
                      <div
                        key={teacher.id}
                        className={`flex items-center justify-between p-2 rounded text-xs border ${
                          isQualified ? 'bg-emerald-50 border-emerald-300' : 'bg-white border-slate-200'
                        }`}
                      >
                        <span className="font-semibold text-slate-800">{teacher.name}</span>
                        <span className={`px-2 py-0.5 rounded text-xs font-medium ${
                          isQualified ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-100 text-slate-500'
                        }`}>
                          {isQualified ? 'Qualified' : 'Not Qualified'}
                        </span>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>

            <div className="flex justify-end gap-3 mt-6 border-t pt-4 border-slate-100">
              <button
                onClick={() => setEditingSubject(null)}
                className="px-4 py-2 border border-slate-300 rounded-lg text-slate-700 hover:bg-slate-50 font-medium text-sm cursor-pointer"
              >
                Cancel
              </button>
              <button
                onClick={handleSave}
                className="flex items-center gap-1.5 bg-indigo-600 text-white px-4 py-2 rounded-lg hover:bg-indigo-700 font-medium text-sm cursor-pointer"
              >
                <Check className="w-4 h-4" /> Save Subject
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
