import React, { useState } from 'react';
import type { Room } from '../types/scheduler';
import { DAYS_OF_WEEK } from '../types/scheduler';
import { Home, Plus, Trash2, Edit2, Check, X, Users } from 'lucide-react';

interface RoomManagerProps {
  rooms: Room[];
  onAddRoom: (room: Room) => void;
  onUpdateRoom: (room: Room) => void;
  onDeleteRoom: (id: string) => void;
}

export const RoomManager: React.FC<RoomManagerProps> = ({
  rooms,
  onAddRoom,
  onUpdateRoom,
  onDeleteRoom,
}) => {
  const [editingRoom, setEditingRoom] = useState<Partial<Room> | null>(null);
  const [isCreating, setIsCreating] = useState(false);

  const startNewRoom = () => {
    setEditingRoom({
      id: 'r-' + Date.now(),
      name: '',
      capacity: 30,
      availability: DAYS_OF_WEEK.map(day => ({
        day,
        slots: [{ start: '08:00', end: '17:00' }]
      }))
    });
    setIsCreating(true);
  };

  const handleSave = () => {
    if (!editingRoom?.name) return;
    const fullRoom: Room = {
      id: editingRoom.id || 'r-' + Date.now(),
      name: editingRoom.name,
      capacity: editingRoom.capacity || 30,
      availability: editingRoom.availability || []
    };

    if (isCreating) {
      onAddRoom(fullRoom);
    } else {
      onUpdateRoom(fullRoom);
    }
    setEditingRoom(null);
    setIsCreating(false);
  };

  const handleTimeSlotChange = (dayIndex: number, slotIndex: number, field: 'start' | 'end', value: string) => {
    if (!editingRoom || !editingRoom.availability) return;
    const newAvail = [...editingRoom.availability];
    newAvail[dayIndex].slots[slotIndex][field] = value;
    setEditingRoom({ ...editingRoom, availability: newAvail });
  };

  const toggleDayAvailable = (dayIndex: number) => {
    if (!editingRoom || !editingRoom.availability) return;
    const newAvail = [...editingRoom.availability];
    if (newAvail[dayIndex].slots.length > 0) {
      newAvail[dayIndex].slots = [];
    } else {
      newAvail[dayIndex].slots = [{ start: '08:00', end: '17:00' }];
    }
    setEditingRoom({ ...editingRoom, availability: newAvail });
  };

  return (
    <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h2 className="text-xl font-bold text-slate-800 flex items-center gap-2">
            <Home className="w-6 h-6 text-indigo-600" />
            Classroom & Lab Management
          </h2>
          <p className="text-sm text-slate-500">
            Configure available rooms, capacity, and operational time availability.
          </p>
        </div>
        <button
          onClick={startNewRoom}
          className="flex items-center gap-2 bg-indigo-600 text-white px-4 py-2 rounded-lg hover:bg-indigo-700 font-medium text-sm transition cursor-pointer"
        >
          <Plus className="w-4 h-4" /> Add Room
        </button>
      </div>

      {/* Grid of Rooms */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {rooms.map(room => (
          <div
            key={room.id}
            className="border border-slate-200 rounded-lg p-4 bg-slate-50/50 hover:shadow-md transition flex flex-col justify-between"
          >
            <div>
              <div className="flex justify-between items-start mb-2">
                <div>
                  <h3 className="font-semibold text-slate-900">{room.name}</h3>
                  <div className="flex items-center gap-1 text-xs text-slate-500 mt-0.5">
                    <Users className="w-3.5 h-3.5 text-slate-400" /> Capacity: {room.capacity || 'N/A'} students
                  </div>
                </div>
                <div className="flex items-center gap-1">
                  <button
                    onClick={() => {
                      setEditingRoom(room);
                      setIsCreating(false);
                    }}
                    className="p-1 text-slate-400 hover:text-indigo-600 rounded cursor-pointer"
                    title="Edit Room"
                  >
                    <Edit2 className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => onDeleteRoom(room.id)}
                    className="p-1 text-slate-400 hover:text-rose-600 rounded cursor-pointer"
                    title="Delete Room"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* Time Availability summary */}
              <div className="mt-3">
                <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider block mb-1">
                  Room Availability:
                </span>
                <div className="text-xs text-slate-600 space-y-0.5 bg-white p-2 rounded border border-slate-100">
                  {room.availability?.map(a => (
                    <div key={a.day} className="flex justify-between items-center py-0.5 border-b border-slate-100 last:border-none">
                      <span className="font-medium text-slate-700">{a.day.substring(0, 3)}:</span>
                      <span>
                        {a.slots.length > 0
                          ? a.slots.map(s => `${s.start}-${s.end}`).join(', ')
                          : 'Closed'}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Edit / Create Room Modal */}
      {editingRoom && (
        <div className="fixed inset-0 bg-slate-900/50 flex items-center justify-center p-4 z-50 backdrop-blur-xs">
          <div className="bg-white rounded-xl shadow-xl max-w-xl w-full max-h-[90vh] overflow-y-auto p-6">
            <div className="flex justify-between items-center mb-4 border-b pb-3 border-slate-100">
              <h3 className="text-lg font-bold text-slate-800">
                {isCreating ? 'Add New Room' : 'Edit Room Details'}
              </h3>
              <button
                onClick={() => setEditingRoom(null)}
                className="text-slate-400 hover:text-slate-600 p-1 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-4">
              <div className="grid grid-cols-3 gap-3">
                <div className="col-span-2">
                  <label className="block text-sm font-medium text-slate-700 mb-1">Room Name / Code</label>
                  <input
                    type="text"
                    value={editingRoom.name || ''}
                    onChange={e => setEditingRoom({ ...editingRoom, name: e.target.value })}
                    placeholder="e.g. Lab 101 or Lecture Hall A"
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:outline-none text-sm text-slate-800 bg-white"
                  />
                </div>
                <div className="col-span-1">
                  <label className="block text-sm font-medium text-slate-700 mb-1">Capacity</label>
                  <input
                    type="number"
                    min="1"
                    value={editingRoom.capacity || 30}
                    onChange={e => setEditingRoom({ ...editingRoom, capacity: parseInt(e.target.value) || 0 })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:outline-none text-sm text-slate-800 bg-white"
                  />
                </div>
              </div>

              {/* Weekly Room Availability */}
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">
                  Weekly Operating Hours & Availability
                </label>
                <div className="space-y-2 border border-slate-200 rounded-lg p-3 bg-slate-50">
                  {editingRoom.availability?.map((dayAvail, dayIdx) => (
                    <div key={dayAvail.day} className="flex flex-wrap items-center justify-between bg-white p-2 rounded border border-slate-200 text-xs">
                      <div className="flex items-center gap-2 w-32">
                        <input
                          type="checkbox"
                          id={`room-day-${dayAvail.day}`}
                          checked={dayAvail.slots.length > 0}
                          onChange={() => toggleDayAvailable(dayIdx)}
                          className="rounded text-indigo-600 cursor-pointer"
                        />
                        <label htmlFor={`room-day-${dayAvail.day}`} className="font-semibold text-slate-800 cursor-pointer">
                          {dayAvail.day}
                        </label>
                      </div>

                      {dayAvail.slots.length > 0 ? (
                        <div className="flex items-center gap-2">
                          <span className="text-slate-500">From</span>
                          <input
                            type="time"
                            value={dayAvail.slots[0]?.start || '08:00'}
                            onChange={e => handleTimeSlotChange(dayIdx, 0, 'start', e.target.value)}
                            className="border border-slate-300 rounded px-1.5 py-1 text-slate-800 bg-white"
                          />
                          <span className="text-slate-500">To</span>
                          <input
                            type="time"
                            value={dayAvail.slots[0]?.end || '17:00'}
                            onChange={e => handleTimeSlotChange(dayIdx, 0, 'end', e.target.value)}
                            className="border border-slate-300 rounded px-1.5 py-1 text-slate-800 bg-white"
                          />
                        </div>
                      ) : (
                        <span className="text-slate-400 italic">Closed on this day</span>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            </div>

            <div className="flex justify-end gap-3 mt-6 border-t pt-4 border-slate-100">
              <button
                onClick={() => setEditingRoom(null)}
                className="px-4 py-2 border border-slate-300 rounded-lg text-slate-700 hover:bg-slate-50 font-medium text-sm cursor-pointer"
              >
                Cancel
              </button>
              <button
                onClick={handleSave}
                className="flex items-center gap-1.5 bg-indigo-600 text-white px-4 py-2 rounded-lg hover:bg-indigo-700 font-medium text-sm cursor-pointer"
              >
                <Check className="w-4 h-4" /> Save Room
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
