import React, { useState } from 'react';
import type { SchoolSettings, BreakTime, DayOfWeek } from '../types/scheduler';
import { DAYS_OF_WEEK } from '../types/scheduler';
import { Settings, Plus, Trash2, Clock, Calendar, Coffee } from 'lucide-react';

interface SchoolSettingsManagerProps {
  settings: SchoolSettings;
  onUpdateSettings: (settings: SchoolSettings) => void;
}

export const SchoolSettingsManager: React.FC<SchoolSettingsManagerProps> = ({
  settings,
  onUpdateSettings,
}) => {
  const [newBreakName, setNewBreakName] = useState('');
  const [newBreakStart, setNewBreakStart] = useState('12:00');
  const [newBreakEnd, setNewBreakEnd] = useState('13:00');
  const [newBreakDay, setNewBreakDay] = useState<DayOfWeek | 'All'>('All');

  const toggleDay = (day: DayOfWeek) => {
    const isOperating = settings.operatingDays.includes(day);
    const updatedDays = isOperating
      ? settings.operatingDays.filter(d => d !== day)
      : [...settings.operatingDays, day];
    
    // Sort operating days according to standard week order
    const sortedDays = DAYS_OF_WEEK.filter(d => updatedDays.includes(d));
    onUpdateSettings({ ...settings, operatingDays: sortedDays });
  };

  const handleAddBreak = () => {
    if (!newBreakName.trim()) return;
    const breakItem: BreakTime = {
      id: 'break-' + Date.now(),
      name: newBreakName.trim(),
      day: newBreakDay,
      start: newBreakStart,
      end: newBreakEnd
    };
    onUpdateSettings({
      ...settings,
      breakTimes: [...settings.breakTimes, breakItem]
    });
    setNewBreakName('');
  };

  const handleDeleteBreak = (id: string) => {
    onUpdateSettings({
      ...settings,
      breakTimes: settings.breakTimes.filter(b => b.id !== id)
    });
  };

  return (
    <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
      <div className="mb-6">
        <h2 className="text-xl font-bold text-slate-800 flex items-center gap-2">
          <Settings className="w-6 h-6 text-indigo-600" />
          School Operating Hours & Break Times
        </h2>
        <p className="text-sm text-slate-500">
          Configure daily operating hours, active school days, time slot resolutions, and institutional break times.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Operating Hours & Days */}
        <div className="space-y-4 border border-slate-200 rounded-lg p-4 bg-slate-50/50">
          <h3 className="font-semibold text-slate-800 flex items-center gap-2 border-b pb-2 border-slate-200 text-sm">
            <Clock className="w-4 h-4 text-indigo-600" /> General Operating Window
          </h3>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">School Opens (Start Time)</label>
              <input
                type="time"
                value={settings.operatingStart}
                onChange={e => onUpdateSettings({ ...settings, operatingStart: e.target.value })}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm text-slate-800 bg-white focus:ring-2 focus:ring-indigo-500"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">School Closes (End Time)</label>
              <input
                type="time"
                value={settings.operatingEnd}
                onChange={e => onUpdateSettings({ ...settings, operatingEnd: e.target.value })}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm text-slate-800 bg-white focus:ring-2 focus:ring-indigo-500"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-700 mb-2 flex items-center gap-1">
              <Calendar className="w-3.5 h-3.5 text-indigo-600" /> Active Operating Days
            </label>
            <div className="flex flex-wrap gap-2">
              {DAYS_OF_WEEK.map(day => {
                const active = settings.operatingDays.includes(day);
                return (
                  <button
                    key={day}
                    type="button"
                    onClick={() => toggleDay(day)}
                    className={`px-3 py-1.5 rounded-lg text-xs font-medium transition cursor-pointer ${
                      active
                        ? 'bg-indigo-600 text-white shadow-xs'
                        : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-100'
                    }`}
                  >
                    {day}
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        {/* Break Times Management */}
        <div className="space-y-4 border border-slate-200 rounded-lg p-4 bg-slate-50/50">
          <h3 className="font-semibold text-slate-800 flex items-center gap-2 border-b pb-2 border-slate-200 text-sm">
            <Coffee className="w-4 h-4 text-amber-600" /> Break Times & Recesses
          </h3>

          {/* Add Break Form */}
          <div className="p-3 bg-white border border-slate-200 rounded-lg space-y-3">
            <span className="text-xs font-semibold text-slate-700 block">Add New Institutional Break</span>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              <input
                type="text"
                placeholder="Break Name (e.g. Lunch Break)"
                value={newBreakName}
                onChange={e => setNewBreakName(e.target.value)}
                className="px-2.5 py-1.5 border border-slate-300 rounded text-xs text-slate-800 bg-white"
              />
              <select
                value={newBreakDay}
                onChange={e => setNewBreakDay(e.target.value as DayOfWeek | 'All')}
                className="px-2.5 py-1.5 border border-slate-300 rounded text-xs text-slate-800 bg-white"
              >
                <option value="All">All Days</option>
                {DAYS_OF_WEEK.map(d => (
                  <option key={d} value={d}>{d}</option>
                ))}
              </select>
            </div>
            <div className="flex items-center gap-2">
              <input
                type="time"
                value={newBreakStart}
                onChange={e => setNewBreakStart(e.target.value)}
                className="px-2 py-1 border border-slate-300 rounded text-xs text-slate-800 bg-white"
              />
              <span className="text-xs text-slate-500">to</span>
              <input
                type="time"
                value={newBreakEnd}
                onChange={e => setNewBreakEnd(e.target.value)}
                className="px-2 py-1 border border-slate-300 rounded text-xs text-slate-800 bg-white"
              />
              <button
                type="button"
                onClick={handleAddBreak}
                className="ml-auto flex items-center gap-1 bg-amber-600 text-white px-3 py-1 rounded text-xs font-medium hover:bg-amber-700 cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" /> Add Break
              </button>
            </div>
          </div>

          {/* Existing Breaks List */}
          <div className="space-y-2">
            {settings.breakTimes.map(b => (
              <div key={b.id} className="flex justify-between items-center bg-white p-2.5 rounded border border-slate-200 text-xs">
                <div>
                  <span className="font-semibold text-slate-800">{b.name}</span>
                  <span className="text-slate-500 ml-2">
                    ({b.day || 'All'} | {b.start} - {b.end})
                  </span>
                </div>
                <button
                  onClick={() => handleDeleteBreak(b.id)}
                  className="text-slate-400 hover:text-rose-600 p-1 rounded cursor-pointer"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            ))}
            {settings.breakTimes.length === 0 && (
              <p className="text-xs text-slate-400 italic text-center py-2">No break times configured.</p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
