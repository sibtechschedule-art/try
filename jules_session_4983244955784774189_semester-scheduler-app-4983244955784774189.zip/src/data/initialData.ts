import type { Teacher, Subject, Room, SchoolSettings, DayOfWeek } from '../types/scheduler';

export const INITIAL_SCHOOL_SETTINGS: SchoolSettings = {
  operatingDays: ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'],
  operatingStart: '08:00',
  operatingEnd: '17:00',
  slotDurationMinutes: 60,
  breakTimes: [
    {
      id: 'break-1',
      name: 'Lunch Break',
      day: 'All',
      start: '12:00',
      end: '13:00'
    }
  ]
};

const fullWeekAvailability: { day: DayOfWeek; slots: { start: string; end: string }[] }[] = [
  { day: 'Monday', slots: [{ start: '08:00', end: '17:00' }] },
  { day: 'Tuesday', slots: [{ start: '08:00', end: '17:00' }] },
  { day: 'Wednesday', slots: [{ start: '08:00', end: '17:00' }] },
  { day: 'Thursday', slots: [{ start: '08:00', end: '17:00' }] },
  { day: 'Friday', slots: [{ start: '08:00', end: '17:00' }] }
];

export const INITIAL_TEACHERS: Teacher[] = [
  {
    id: 't-1',
    name: 'Dr. Alan Turing',
    email: 'alan.turing@school.edu',
    qualifiedSubjectIds: ['sub-1', 'sub-2'],
    availability: fullWeekAvailability
  },
  {
    id: 't-2',
    name: 'Prof. Grace Hopper',
    email: 'grace.hopper@school.edu',
    qualifiedSubjectIds: ['sub-2', 'sub-3'],
    availability: fullWeekAvailability
  },
  {
    id: 't-3',
    name: 'Dr. Katherine Johnson',
    email: 'katherine.j@school.edu',
    qualifiedSubjectIds: ['sub-1', 'sub-4'],
    availability: fullWeekAvailability
  },
  {
    id: 't-4',
    name: 'Prof. Ada Lovelace',
    email: 'ada.lovelace@school.edu',
    qualifiedSubjectIds: ['sub-3', 'sub-4'],
    availability: fullWeekAvailability
  }
];

export const INITIAL_SUBJECTS: Subject[] = [
  {
    id: 'sub-1',
    name: 'Introduction to Computer Science',
    code: 'CS101',
    color: '#3b82f6', // blue
    calculationMode: 'semester',
    totalSemesterHours: 45,
    weeksInSemester: 15,
    hoursPerWeek: 3,
    sessionsPerWeek: 2,
    sessionDurationHours: 1.5,
    preferredTeacherIds: ['t-1', 't-3']
  },
  {
    id: 'sub-2',
    name: 'Data Structures & Algorithms',
    code: 'CS201',
    color: '#10b981', // green
    calculationMode: 'weekly',
    totalSemesterHours: 60,
    weeksInSemester: 15,
    hoursPerWeek: 4,
    sessionsPerWeek: 2,
    sessionDurationHours: 2,
    preferredTeacherIds: ['t-1', 't-2']
  },
  {
    id: 'sub-3',
    name: 'Database Management Systems',
    code: 'CS301',
    color: '#f59e0b', // amber
    calculationMode: 'weekly',
    totalSemesterHours: 45,
    weeksInSemester: 15,
    hoursPerWeek: 3,
    sessionsPerWeek: 2,
    sessionDurationHours: 1.5,
    preferredTeacherIds: ['t-2', 't-4']
  },
  {
    id: 'sub-4',
    name: 'Calculus & Applied Math',
    code: 'MATH101',
    color: '#8b5cf6', // purple
    calculationMode: 'semester',
    totalSemesterHours: 60,
    weeksInSemester: 15,
    hoursPerWeek: 4,
    sessionsPerWeek: 2,
    sessionDurationHours: 2,
    preferredTeacherIds: ['t-3', 't-4']
  }
];

export const INITIAL_ROOMS: Room[] = [
  {
    id: 'r-1',
    name: 'Lab 101 - Computing Center',
    capacity: 40,
    availability: fullWeekAvailability
  },
  {
    id: 'r-2',
    name: 'Lecture Hall A',
    capacity: 100,
    availability: fullWeekAvailability
  },
  {
    id: 'r-3',
    name: 'Room 204 - Math Seminar',
    capacity: 30,
    availability: fullWeekAvailability
  }
];
