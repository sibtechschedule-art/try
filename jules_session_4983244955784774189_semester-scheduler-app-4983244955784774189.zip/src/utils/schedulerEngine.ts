import type {
  Teacher,
  Subject,
  Room,
  SchoolSettings,
  ScheduledSession,
  ScheduleConflict,
  DayOfWeek
} from '../types/scheduler';

/**
 * Utility to convert "HH:mm" time string into minutes from midnight for easy comparison.
 */
export function timeToMinutes(timeStr: string): number {
  if (!timeStr) return 0;
  const [h, m] = timeStr.split(':').map(Number);
  return h * 60 + m;
}

/**
 * Utility to convert minutes from midnight into "HH:mm" time string.
 */
export function minutesToTime(mins: number): string {
  const h = Math.floor(mins / 60);
  const m = mins % 60;
  return `${h.toString().padStart(2, '0')}:${m.toString().padStart(2, '0')}`;
}

/**
 * Check if two time intervals [start1, end1) and [start2, end2) overlap.
 */
export function doIntervalsOverlap(s1: number, e1: number, s2: number, e2: number): boolean {
  return Math.max(s1, s2) < Math.min(e1, e2);
}

/**
 * Validates whether a time window lies within teacher/room availability.
 */
function isWithinAvailability(
  day: DayOfWeek,
  startMins: number,
  endMins: number,
  availability: { day: DayOfWeek; slots: { start: string; end: string }[] }[]
): boolean {
  const dayAvail = availability.find(a => a.day === day);
  if (!dayAvail || dayAvail.slots.length === 0) return false;

  return dayAvail.slots.some(slot => {
    const slotStart = timeToMinutes(slot.start);
    const slotEnd = timeToMinutes(slot.end);
    return startMins >= slotStart && endMins <= slotEnd;
  });
}

/**
 * Conflict detection engine that analyzes all current scheduled sessions
 * against teacher availability, room availability, break times, double bookings,
 * and teacher qualification rules.
 */
export function detectScheduleConflicts(
  sessions: ScheduledSession[],
  teachers: Teacher[],
  subjects: Subject[],
  rooms: Room[],
  settings: SchoolSettings
): ScheduleConflict[] {
  const conflicts: ScheduleConflict[] = [];

  sessions.forEach((session, idx) => {
    const teacher = teachers.find(t => t.id === session.teacherId);
    const subject = subjects.find(s => s.id === session.subjectId);
    const room = rooms.find(r => r.id === session.roomId);

    const sStart = timeToMinutes(session.startTime);
    const sEnd = timeToMinutes(session.endTime);

    const teacherName = teacher ? teacher.name : 'Unassigned Teacher';
    const roomName = room ? room.name : 'Unassigned Room';
    const subjectName = subject ? `${subject.code} (${subject.name})` : 'Unknown Subject';

    // 1. Check Teacher Qualification
    if (teacher && subject) {
      if (!teacher.qualifiedSubjectIds.includes(subject.id)) {
        conflicts.push({
          id: `conflict-qual-${session.id}`,
          type: 'TEACHER_UNQUALIFIED',
          sessionId: session.id,
          message: `${teacherName} is not marked as qualified to teach ${subjectName}.`,
          severity: 'warning'
        });
      }
    }

    // 2. Check Teacher Availability
    if (teacher) {
      if (!isWithinAvailability(session.day, sStart, sEnd, teacher.availability)) {
        conflicts.push({
          id: `conflict-tavail-${session.id}`,
          type: 'TEACHER_UNAVAILABLE',
          sessionId: session.id,
          message: `${teacherName} is not available on ${session.day} between ${session.startTime} and ${session.endTime}.`,
          severity: 'error'
        });
      }
    }

    // 3. Check Room Availability
    if (room) {
      if (!isWithinAvailability(session.day, sStart, sEnd, room.availability)) {
        conflicts.push({
          id: `conflict-ravail-${session.id}`,
          type: 'ROOM_UNAVAILABLE',
          sessionId: session.id,
          message: `${roomName} is not available on ${session.day} between ${session.startTime} and ${session.endTime}.`,
          severity: 'error'
        });
      }
    }

    // 4. Check Break Time Overlap
    settings.breakTimes.forEach(breakItem => {
      const isBreakDay = breakItem.day === 'All' || breakItem.day === session.day;
      if (isBreakDay) {
        const bStart = timeToMinutes(breakItem.start);
        const bEnd = timeToMinutes(breakItem.end);
        if (doIntervalsOverlap(sStart, sEnd, bStart, bEnd)) {
          conflicts.push({
            id: `conflict-break-${session.id}-${breakItem.id}`,
            type: 'BREAK_TIME_OVERLAP',
            sessionId: session.id,
            message: `Session for ${subjectName} overlaps with institutional break "${breakItem.name}" (${breakItem.start}-${breakItem.end}).`,
            severity: 'error'
          });
        }
      }
    });

    // 5. Check Double Bookings with other sessions
    for (let j = idx + 1; j < sessions.length; j++) {
      const other = sessions[j];
      if (other.day !== session.day) continue;

      const oStart = timeToMinutes(other.startTime);
      const oEnd = timeToMinutes(other.endTime);

      if (doIntervalsOverlap(sStart, sEnd, oStart, oEnd)) {
        const otherSubject = subjects.find(s => s.id === other.subjectId);
        const otherSubjectName = otherSubject ? `${otherSubject.code}` : 'another course';

        // Teacher double booking
        if (session.teacherId && session.teacherId === other.teacherId) {
          conflicts.push({
            id: `conflict-tdouble-${session.id}-${other.id}`,
            type: 'TEACHER_DOUBLE_BOOKING',
            sessionId: session.id,
            competingSessionId: other.id,
            message: `${teacherName} is double-booked on ${session.day} at ${session.startTime}-${session.endTime} (${subjectName} vs ${otherSubjectName}).`,
            severity: 'error'
          });
        }

        // Room double booking
        if (session.roomId && session.roomId === other.roomId) {
          conflicts.push({
            id: `conflict-rdouble-${session.id}-${other.id}`,
            type: 'ROOM_DOUBLE_BOOKING',
            sessionId: session.id,
            competingSessionId: other.id,
            message: `${roomName} is double-booked on ${session.day} at ${session.startTime}-${session.endTime} (${subjectName} vs ${otherSubjectName}).`,
            severity: 'error'
          });
        }
      }
    }
  });

  return conflicts;
}

/**
 * Constraint-Satisfaction Automatic Schedule Generator
 * Generates non-conflicting schedules for subjects, teachers, and rooms
 * according to Operating Hours, Break Times, and Availabilities.
 */
export function generateAutoSchedule(
  teachers: Teacher[],
  subjects: Subject[],
  rooms: Room[],
  settings: SchoolSettings
): { sessions: ScheduledSession[]; conflicts: ScheduleConflict[] } {
  const generatedSessions: ScheduledSession[] = [];

  const schoolStartMins = timeToMinutes(settings.operatingStart);
  const schoolEndMins = timeToMinutes(settings.operatingEnd);
  const slotStepMins = settings.slotDurationMinutes || 30; // 30 or 60 min step

  // Loop through all subjects
  subjects.forEach(subject => {
    const requiredSessions = Math.max(1, subject.sessionsPerWeek);
    const durationMins = Math.round((subject.sessionDurationHours || 1.5) * 60);

    // Find qualified teachers for this subject
    let candidateTeachers = teachers.filter(t => t.qualifiedSubjectIds.includes(subject.id));
    if (candidateTeachers.length === 0) {
      candidateTeachers = [...teachers]; // Fallback if none qualified
    }

    let sessionsPlaced = 0;

    // Try placing required sessions across operating days
    for (const day of settings.operatingDays) {
      if (sessionsPlaced >= requiredSessions) break;

      // Try timeslots in steps
      for (let t = schoolStartMins; t <= schoolEndMins - durationMins; t += slotStepMins) {
        if (sessionsPlaced >= requiredSessions) break;

        const slotStartStr = minutesToTime(t);
        const slotEndStr = minutesToTime(t + durationMins);

        // Check break time overlap
        const overlapsBreak = settings.breakTimes.some(b => {
          const isBreakDay = b.day === 'All' || b.day === day;
          if (!isBreakDay) return false;
          return doIntervalsOverlap(t, t + durationMins, timeToMinutes(b.start), timeToMinutes(b.end));
        });
        if (overlapsBreak) continue;

        // Try candidate teachers and candidate rooms
        let placed = false;

        for (const teacher of candidateTeachers) {
          if (placed) break;

          // Check teacher availability
          if (!isWithinAvailability(day, t, t + durationMins, teacher.availability)) continue;

          // Check if teacher is already booked
          const teacherBusy = generatedSessions.some(
            s => s.day === day && s.teacherId === teacher.id &&
              doIntervalsOverlap(t, t + durationMins, timeToMinutes(s.startTime), timeToMinutes(s.endTime))
          );
          if (teacherBusy) continue;

          for (const room of rooms) {
            // Check room availability
            if (!isWithinAvailability(day, t, t + durationMins, room.availability)) continue;

            // Check if room is already booked
            const roomBusy = generatedSessions.some(
              s => s.day === day && s.roomId === room.id &&
                doIntervalsOverlap(t, t + durationMins, timeToMinutes(s.startTime), timeToMinutes(s.endTime))
            );
            if (roomBusy) continue;

            // Place session!
            generatedSessions.push({
              id: `session-${subject.id}-${sessionsPlaced + 1}-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
              subjectId: subject.id,
              teacherId: teacher.id,
              roomId: room.id,
              day,
              startTime: slotStartStr,
              endTime: slotEndStr,
              sessionIndex: sessionsPlaced + 1
            });

            sessionsPlaced++;
            placed = true;
            break;
          }
        }
      }
    }
  });

  const conflicts = detectScheduleConflicts(generatedSessions, teachers, subjects, rooms, settings);
  return { sessions: generatedSessions, conflicts };
}
