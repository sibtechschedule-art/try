import { describe, it, expect } from 'vitest';
import { generateAutoSchedule, detectScheduleConflicts } from './schedulerEngine';
import { INITIAL_TEACHERS, INITIAL_SUBJECTS, INITIAL_ROOMS, INITIAL_SCHOOL_SETTINGS } from '../data/initialData';
import type { ScheduledSession } from '../types/scheduler';

describe('Scheduler Engine Logic', () => {
  it('should generate non-conflicting schedule from initial data', () => {
    const { sessions, conflicts } = generateAutoSchedule(
      INITIAL_TEACHERS,
      INITIAL_SUBJECTS,
      INITIAL_ROOMS,
      INITIAL_SCHOOL_SETTINGS
    );

    expect(sessions.length).toBeGreaterThan(0);
    expect(conflicts.length).toBe(0);
  });

  it('should detect teacher double-booking conflicts', () => {
    const testSessions: ScheduledSession[] = [
      {
        id: 's1',
        subjectId: 'sub-1',
        teacherId: 't-1',
        roomId: 'r-1',
        day: 'Monday',
        startTime: '09:00',
        endTime: '10:30',
        sessionIndex: 1
      },
      {
        id: 's2',
        subjectId: 'sub-2',
        teacherId: 't-1', // Same teacher!
        roomId: 'r-2',
        day: 'Monday',
        startTime: '10:00', // Overlaps with 09:00-10:30
        endTime: '11:30',
        sessionIndex: 1
      }
    ];

    const conflicts = detectScheduleConflicts(
      testSessions,
      INITIAL_TEACHERS,
      INITIAL_SUBJECTS,
      INITIAL_ROOMS,
      INITIAL_SCHOOL_SETTINGS
    );

    expect(conflicts.some(c => c.type === 'TEACHER_DOUBLE_BOOKING')).toBe(true);
  });

  it('should detect break time overlap conflicts', () => {
    const testSessions: ScheduledSession[] = [
      {
        id: 's1',
        subjectId: 'sub-1',
        teacherId: 't-1',
        roomId: 'r-1',
        day: 'Monday',
        startTime: '11:30',
        endTime: '12:30', // Overlaps with Lunch Break 12:00-13:00
        sessionIndex: 1
      }
    ];

    const conflicts = detectScheduleConflicts(
      testSessions,
      INITIAL_TEACHERS,
      INITIAL_SUBJECTS,
      INITIAL_ROOMS,
      INITIAL_SCHOOL_SETTINGS
    );

    expect(conflicts.some(c => c.type === 'BREAK_TIME_OVERLAP')).toBe(true);
  });
});
