export type DayOfWeek = 'Monday' | 'Tuesday' | 'Wednesday' | 'Thursday' | 'Friday' | 'Saturday';

export const DAYS_OF_WEEK: DayOfWeek[] = [
  'Monday',
  'Tuesday',
  'Wednesday',
  'Thursday',
  'Friday',
  'Saturday'
];

export interface TimeSlot {
  start: string; // HH:mm format, e.g. "08:00"
  end: string;   // HH:mm format, e.g. "12:00"
}

export interface DayAvailability {
  day: DayOfWeek;
  slots: TimeSlot[]; // Available time windows on this day
}

export interface Teacher {
  id: string;
  name: string;
  email?: string;
  qualifiedSubjectIds: string[]; // Subject IDs teacher can teach
  availability: DayAvailability[];
}

export type HourCalculationMode = 'weekly' | 'semester';

export interface Subject {
  id: string;
  name: string;
  code: string; // e.g. "CS101"
  color?: string; // Hex or CSS class for visual display
  calculationMode: HourCalculationMode;
  totalSemesterHours: number; // e.g. 45 hours
  weeksInSemester: number; // e.g. 15 weeks
  hoursPerWeek: number; // e.g. 3 hours/week (computed or manually adjusted)
  sessionsPerWeek: number; // e.g. 2 sessions per week
  sessionDurationHours: number; // e.g. 1.5 hours per session (hoursPerWeek / sessionsPerWeek)
  preferredTeacherIds?: string[];
}

export interface Room {
  id: string;
  name: string; // e.g. "Lab 101" or "Lecture Hall A"
  capacity?: number;
  availability: DayAvailability[];
}

export interface BreakTime {
  id: string;
  name: string; // e.g. "Lunch Break"
  day?: DayOfWeek | 'All'; // Specific day or all operating days
  start: string; // "12:00"
  end: string;   // "13:00"
}

export interface SchoolSettings {
  operatingDays: DayOfWeek[];
  operatingStart: string; // "08:00"
  operatingEnd: string;   // "17:00"
  slotDurationMinutes: number; // e.g. 30 or 60 min intervals
  breakTimes: BreakTime[];
}

export interface ScheduledSession {
  id: string;
  subjectId: string;
  teacherId: string;
  roomId: string;
  day: DayOfWeek;
  startTime: string; // "09:00"
  endTime: string;   // "10:30"
  sessionIndex: number; // Session 1 of 2, etc.
}

export type ConflictType = 
  | 'TEACHER_DOUBLE_BOOKING'
  | 'ROOM_DOUBLE_BOOKING'
  | 'TEACHER_UNQUALIFIED'
  | 'TEACHER_UNAVAILABLE'
  | 'ROOM_UNAVAILABLE'
  | 'BREAK_TIME_OVERLAP';

export interface ScheduleConflict {
  id: string;
  type: ConflictType;
  sessionId: string;
  competingSessionId?: string;
  message: string;
  severity: 'error' | 'warning';
}

export interface ScheduleState {
  teachers: Teacher[];
  subjects: Subject[];
  rooms: Room[];
  settings: SchoolSettings;
  sessions: ScheduledSession[];
  conflicts: ScheduleConflict[];
}
