import { useState, useEffect } from 'react';
import type { Teacher, Subject, Room, SchoolSettings, ScheduledSession, ScheduleConflict } from './types/scheduler';
import { INITIAL_TEACHERS, INITIAL_SUBJECTS, INITIAL_ROOMS, INITIAL_SCHOOL_SETTINGS } from './data/initialData';
import { generateAutoSchedule, detectScheduleConflicts } from './utils/schedulerEngine';
import { TeacherManager } from './components/TeacherManager';
import { SubjectManager } from './components/SubjectManager';
import { RoomManager } from './components/RoomManager';
import { SchoolSettingsManager } from './components/SchoolSettingsManager';
import { TimetableGrid } from './components/TimetableGrid';
import { Calendar, UserCheck, BookOpen, Home, Settings, AlertTriangle, CheckCircle2, Sparkles } from 'lucide-react';

export function App() {
  const [activeTab, setActiveTab] = useState<'schedule' | 'teachers' | 'subjects' | 'rooms' | 'settings'>('schedule');

  const [teachers, setTeachers] = useState<Teacher[]>(INITIAL_TEACHERS);
  const [subjects, setSubjects] = useState<Subject[]>(INITIAL_SUBJECTS);
  const [rooms, setRooms] = useState<Room[]>(INITIAL_ROOMS);
  const [settings, setSettings] = useState<SchoolSettings>(INITIAL_SCHOOL_SETTINGS);

  const [sessions, setSessions] = useState<ScheduledSession[]>([]);
  const [conflicts, setConflicts] = useState<ScheduleConflict[]>([]);

  // Automatically generate initial schedule on mount
  useEffect(() => {
    handleAutoGenerate();
  }, []);

  // Re-run conflict detection whenever sessions or core data changes
  useEffect(() => {
    const detected = detectScheduleConflicts(sessions, teachers, subjects, rooms, settings);
    setConflicts(detected);
  }, [sessions, teachers, subjects, rooms, settings]);

  const handleAutoGenerate = () => {
    const { sessions: generated, conflicts: detected } = generateAutoSchedule(teachers, subjects, rooms, settings);
    setSessions(generated);
    setConflicts(detected);
  };

  // Session Handlers
  const handleUpdateSession = (updatedSession: ScheduledSession) => {
    setSessions(prev => prev.map(s => s.id === updatedSession.id ? updatedSession : s));
  };

  const handleDeleteSession = (sessionId: string) => {
    setSessions(prev => prev.filter(s => s.id !== sessionId));
  };

  const handleSwapTeachers = (sessionId1: string, sessionId2: string) => {
    setSessions(prev => {
      const s1 = prev.find(s => s.id === sessionId1);
      const s2 = prev.find(s => s.id === sessionId2);
      if (!s1 || !s2) return prev;

      return prev.map(s => {
        if (s.id === sessionId1) return { ...s, teacherId: s2.teacherId };
        if (s.id === sessionId2) return { ...s, teacherId: s1.teacherId };
        return s;
      });
    });
  };

  const handleAssignTeacherToSession = (sessionId: string, newTeacherId: string) => {
    setSessions(prev => prev.map(s => s.id === sessionId ? { ...s, teacherId: newTeacherId } : s));
  };

  // Teacher Handlers
  const handleAddTeacher = (teacher: Teacher) => setTeachers(prev => [...prev, teacher]);
  const handleUpdateTeacher = (teacher: Teacher) => setTeachers(prev => prev.map(t => t.id === teacher.id ? teacher : t));
  const handleDeleteTeacher = (id: string) => setTeachers(prev => prev.filter(t => t.id !== id));

  // Subject Handlers
  const handleAddSubject = (subject: Subject) => setSubjects(prev => [...prev, subject]);
  const handleUpdateSubject = (subject: Subject) => setSubjects(prev => prev.map(s => s.id === subject.id ? subject : s));
  const handleDeleteSubject = (id: string) => setSubjects(prev => prev.filter(s => s.id !== id));

  // Room Handlers
  const handleAddRoom = (room: Room) => setRooms(prev => [...prev, room]);
  const handleUpdateRoom = (room: Room) => setRooms(prev => prev.map(r => r.id === room.id ? room : r));
  const handleDeleteRoom = (id: string) => setRooms(prev => prev.filter(r => r.id !== id));

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 pb-12">
      {/* Top Navbar */}
      <header className="bg-slate-900 text-white shadow-md sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3.5 flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-indigo-600 rounded-lg text-white shadow-sm">
              <Calendar className="w-6 h-6" />
            </div>
            <div>
              <h1 className="text-xl font-bold tracking-tight text-white m-0 leading-tight">
                Semester Schedule Planner
              </h1>
              <p className="text-xs text-slate-400">Automatic Scheduler & Interactive Timetable</p>
            </div>
          </div>

          {/* Quick Actions */}
          <div className="flex items-center gap-3">
            <button
              id="auto-generate-btn"
              onClick={handleAutoGenerate}
              className="flex items-center gap-2 bg-indigo-600 hover:bg-indigo-500 text-white px-4 py-2 rounded-lg font-medium text-xs shadow-sm transition cursor-pointer"
            >
              <Sparkles className="w-4 h-4" /> Auto-Generate Schedule
            </button>
          </div>
        </div>

        {/* Tab Navigation Bar */}
        <div className="bg-slate-800 border-t border-slate-700/60 px-4 sm:px-6 lg:px-8">
          <div className="max-w-7xl mx-auto flex overflow-x-auto gap-1 py-1">
            <button
              id="tab-schedule"
              onClick={() => setActiveTab('schedule')}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-lg text-xs font-semibold transition cursor-pointer ${
                activeTab === 'schedule'
                  ? 'bg-indigo-600 text-white shadow-xs'
                  : 'text-slate-300 hover:bg-slate-700/50 hover:text-white'
              }`}
            >
              <Calendar className="w-4 h-4" /> Schedule Dashboard
              {conflicts.length > 0 && (
                <span className="ml-1 bg-rose-500 text-white text-[10px] px-1.5 py-0.5 rounded-full font-bold">
                  {conflicts.length}
                </span>
              )}
            </button>

            <button
              id="tab-teachers"
              onClick={() => setActiveTab('teachers')}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-lg text-xs font-semibold transition cursor-pointer ${
                activeTab === 'teachers'
                  ? 'bg-indigo-600 text-white shadow-xs'
                  : 'text-slate-300 hover:bg-slate-700/50 hover:text-white'
              }`}
            >
              <UserCheck className="w-4 h-4" /> Teachers ({teachers.length})
            </button>

            <button
              id="tab-subjects"
              onClick={() => setActiveTab('subjects')}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-lg text-xs font-semibold transition cursor-pointer ${
                activeTab === 'subjects'
                  ? 'bg-indigo-600 text-white shadow-xs'
                  : 'text-slate-300 hover:bg-slate-700/50 hover:text-white'
              }`}
            >
              <BookOpen className="w-4 h-4" /> Subjects ({subjects.length})
            </button>

            <button
              id="tab-rooms"
              onClick={() => setActiveTab('rooms')}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-lg text-xs font-semibold transition cursor-pointer ${
                activeTab === 'rooms'
                  ? 'bg-indigo-600 text-white shadow-xs'
                  : 'text-slate-300 hover:bg-slate-700/50 hover:text-white'
              }`}
            >
              <Home className="w-4 h-4" /> Rooms ({rooms.length})
            </button>

            <button
              id="tab-settings"
              onClick={() => setActiveTab('settings')}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-lg text-xs font-semibold transition cursor-pointer ${
                activeTab === 'settings'
                  ? 'bg-indigo-600 text-white shadow-xs'
                  : 'text-slate-300 hover:bg-slate-700/50 hover:text-white'
              }`}
            >
              <Settings className="w-4 h-4" /> Operating Settings
            </button>
          </div>
        </div>
      </header>

      {/* Main Content Area */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-6">
        {/* Real-time Conflict Ping Banner */}
        {activeTab === 'schedule' && conflicts.length > 0 && (
          <div className="mb-6 bg-rose-50 border-l-4 border-rose-500 rounded-r-xl p-4 shadow-xs">
            <div className="flex items-start justify-between">
              <div className="flex items-start gap-3">
                <AlertTriangle className="w-5 h-5 text-rose-600 shrink-0 mt-0.5" />
                <div>
                  <h3 className="text-sm font-bold text-rose-900">
                    Conflict Warning Ping ({conflicts.length} issue{conflicts.length > 1 ? 's' : ''} detected)
                  </h3>
                  <p className="text-xs text-rose-700 mt-0.5">
                    Schedule violations found in current arrangement. Drag slots or swap teachers to resolve.
                  </p>
                  <ul className="mt-2 space-y-1 text-xs text-rose-800 font-medium">
                    {conflicts.slice(0, 3).map(c => (
                      <li key={c.id} className="flex items-center gap-1.5">
                        <span className="w-1.5 h-1.5 rounded-full bg-rose-500 shrink-0" />
                        {c.message}
                      </li>
                    ))}
                    {conflicts.length > 3 && (
                      <li className="text-[11px] text-rose-600 font-normal italic">
                        + {conflicts.length - 3} additional conflicts...
                      </li>
                    )}
                  </ul>
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'schedule' && conflicts.length === 0 && sessions.length > 0 && (
          <div className="mb-6 bg-emerald-50 border-l-4 border-emerald-500 rounded-r-xl p-3 shadow-xs flex items-center gap-2 text-emerald-900 text-xs font-medium">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            Schedule fully optimized and conflict-free! All teacher availability, room availability, and break time constraints satisfied.
          </div>
        )}

        {/* Tab Views */}
        {activeTab === 'schedule' && (
          <TimetableGrid
            sessions={sessions}
            teachers={teachers}
            subjects={subjects}
            rooms={rooms}
            conflicts={conflicts}
            operatingDays={settings.operatingDays}
            operatingStart={settings.operatingStart}
            operatingEnd={settings.operatingEnd}
            onUpdateSession={handleUpdateSession}
            onDeleteSession={handleDeleteSession}
            onSwapTeachers={handleSwapTeachers}
            onAssignTeacherToSession={handleAssignTeacherToSession}
          />
        )}

        {activeTab === 'teachers' && (
          <TeacherManager
            teachers={teachers}
            subjects={subjects}
            onAddTeacher={handleAddTeacher}
            onUpdateTeacher={handleUpdateTeacher}
            onDeleteTeacher={handleDeleteTeacher}
          />
        )}

        {activeTab === 'subjects' && (
          <SubjectManager
            subjects={subjects}
            teachers={teachers}
            onAddSubject={handleAddSubject}
            onUpdateSubject={handleUpdateSubject}
            onDeleteSubject={handleDeleteSubject}
          />
        )}

        {activeTab === 'rooms' && (
          <RoomManager
            rooms={rooms}
            onAddRoom={handleAddRoom}
            onUpdateRoom={handleUpdateRoom}
            onDeleteRoom={handleDeleteRoom}
          />
        )}

        {activeTab === 'settings' && (
          <SchoolSettingsManager
            settings={settings}
            onUpdateSettings={setSettings}
          />
        )}
      </main>
    </div>
  );
}

export default App;
